
# Installation Linux


````bash
# Clone
git clone https://github.com/usebruno/bruno

# On Linux via Snap
snap install bruno

````


# Utilisation


````bash
curl -X POST http://localhost:8080/analyze \
  -F "file=@Bulletin_6Pages.pdf"
bru curl -X POST http://localhost:8080/analyze \
  -F "file=@Bulletin_6Pages.pdf"

````