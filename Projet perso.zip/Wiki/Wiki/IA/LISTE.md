
# Liste des IA

* Chatgpt (Global)
* Bruno (Test et validation)
* Cursorio (code)
* Cursordcode (csvode, correction et commentaire)



