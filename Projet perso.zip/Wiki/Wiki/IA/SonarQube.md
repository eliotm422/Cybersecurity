
Test de code, lien pour installer :
https://0xnehru.medium.com/step-by-step-guide-to-installing-and-setting-up-sonarqube-on-kali-linux-a73fd793e9b8