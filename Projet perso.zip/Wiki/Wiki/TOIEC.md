
file:///C:/Users/eliot/Downloads/Lougheed%20Test%203.pdf

# Test numéro 3

## Part 1 



1 : C
2 : A 
3 : C B
4 : ?? 
5 : A
6 : A
7 : A
8 : ?
9 : B
10 : B


## Part 2 


11 : B 
12 : B
13 : C
14 : A
15 : B
16 : C
17 : B 
18 : B
19 : A 
20 : A
21 : C
22 : A
23 : C
24 : C
25 : B
26 : A
27 : B
28 : C
29 : C
30 : B
31 : C
32 : C
33 : A
34 : A C
35 : B
36 : A
37 : A
38 : B
39 : B
40 : C


## Part 3 


41 : B

42 : C

43 : C 
###
44 : D

45 : A

46 : B

###
47 : B C

48 : A

49 : D 
###
50 : C A 

51 : B

52 : B
###

53 : A

54 : D

55 : B D

###

56 : C

57 : B

58 : B

###

59 : D

60 : C

61 :  A

###


62 : B

63 : B
 
64 : D

###

65 : A

66 : C

67 : C

###

68 : D

69 : A

70 : A

## Part 4 

###

71 : B

72 : A

73 : B

###

74 :  B D 

75 : A

76 : C

###


77 : D

78 : B A

79 : D

###

80 :  C

81 : B

82 : C B 

###

83 : D

84 : B

85 : B

###

86 : A

87 : C B

88 : C

###

89 : B

90 : A

91 : A

###

92 : D

93 : C

94 : B
 
###

95 : D

96 :  D

97 : B

###

98 : D

99 : A

100 : C 


## Part 4 

101 :  B C

102 : A

103 : D

104 : D

105 : C A

106 :  C B

107 : B

108 : B C

109 : D B

110 : C D

111 : A C

112 : C

113 : B A

114 : A 

115 : A D

116 : D C

117 : B A

118 : D

119 : C D

120 :  C B

121 : D 

122 : A

123 : C

124 : A

125 : B

126 : A B

127 : A

128 : D

129 : C

130 : C

131 : D

132 : C A

133 : B D

134 : C

135 : A B

136 : D 

137 : A

138 : C

139 : B

140 : B C


## Part 6 

### Question 141 143

141 : A

142 : A

143 :  D
### Question 144 146

144 : D

145 : B

146 : B

### Question 147 149

147 : D A

148 : B C

149 : B


### Question 150 152

150 : C B 

151 : A

152 : D C

## Part 7 

153 : C

154 : D

155 : A

### Question 156 158

156 : B

157 : A

158 : C

### Question 159 161 

159 : C

160 : B

161 : D

### Question 162 165 

162 : D

163 : D

164 : A

165 : B


### Question 166 169

166 : B A

167 : A

168 : B

169 : C 

### Question 170 171

170 : B

171 : C

### Question 172 173 

172 : B

173 : D

### Question 174 177

174 : D B 

175 : D A

176 : B 

177 :  A

### Question 178 180



178 : B

179 : A

180  A C



### Question 181 185

181 : B

182 : D

183 : A

184 : A D

185 : B C

### Question 186 190

186 : D

187 : B

188 : C

189 : D

190 : B A

### Question 191 195

191 C

192 : B

193 : A B

194 : A

195 : b

### Question 196 200

196 : A C

197 :  c

198 : b A

199 : D

200 : B