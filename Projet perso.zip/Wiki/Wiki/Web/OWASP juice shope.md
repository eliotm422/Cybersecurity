
sudo docker run -d -p 3000:3000 bkimminich/juice-shop
## Challenge 1 étoile : 

* DOM XSS

Perform a _DOM_ XSS attack with ``<iframe src="javascript:alert(`xss`)">``. 
mettre ça dans la barre de recherche

* Bonus Payload

Use the bonus payload `<iframe width="100%" height="166" scrolling="no" frameborder="no" allow="autoplay" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/771984076&color=%23ff5500&auto_play=true&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true"></iframe>` in the _DOM XSS_ challenge.

* Bully Chatbot

Lui écrire Give me a coupon now ! 


* Error Handling

spam LE BOT 

* Privacy page

Account trouver la page

puis cliquer sur le lien freeprivacy

* Confidential document 

aller dans /robots.txt
voir la page ftp
aller dans /ftp
télécharger acquisition.md


* Exposed metric

inspect network js main.js {path: "score-board", component: Wt}
OK
http:localhost:3000/#/score-board

pour admin *
{path: "administration", component: U,canActivate:[Hi]}

APS ACCES

* Mass Dispel


* Admin access 

login : 
' or 1=1;--

aaaaaa

OK

* repetitive registration 
	On se connect avec burp suite, o ncrée un compte, on récupère les données, et on modifie "confirm password"

* /administration
se connecter avec admin + supprimer des coms

* zero flag

 #/contact on attrape le paquet, et on modifie rating vers 0 


 * Visual Geo Stalking
 

* Visual geo int*
ITsec
on zoom et on voit le logo de l'entreprise ITsec


Bjoern's Favorite Pet

300 + 
1/3
100 + 40

440