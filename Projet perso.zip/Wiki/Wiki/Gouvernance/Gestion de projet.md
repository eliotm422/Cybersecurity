

6 indicateurs : 
coûts
délais
durabilité
bénéfice
qualité
scope

risques 

MOA : client

MOE : gestion du projet au quotidien

AMOA : aide le client à rédiger le cahier des charges  


Agilité : Itéraiton, Incrément

Scrum : Transparence, Inspection, Adaptation


M S C W : Du plus ou moins important 
