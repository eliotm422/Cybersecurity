



5 pôles de compétences pour une entreprise :
![[Pasted image 20240514135832.png]]

Gérer le projet de création de l'entreprise :

Idée : Porteur de l'idée, on trouve la ou les personnes pour porter le projet jusqu'au bout 
Deux possibilités : 
LEAN :
* On produit par itération, on produit un objet simple, et avec le retour utilisateur on améliore le produit
Etude de marché : 
* Une fois que l'équipe est trouvée, on commence à faire des études de marché. On réalise des questionnaires pour connaître le besoin du marché.
* Echelle micro : ce qu'on contrôle 
* Echelle macro : ce que l'on ne contrôle pas 
* zone de chalandise : zone entre la production commerciale et la zone de vente 

Stratégie commerciale

Prévisionnel de finance 

Les statuts (cadre juridique social fiscal)

Tout cela c'est le buiseness plan ! 
Ordre : 
* D'abord proposition de valeur 
* Segmentation clientèle (qui ?)