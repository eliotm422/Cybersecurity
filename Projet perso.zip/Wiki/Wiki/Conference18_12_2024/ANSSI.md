

- Lockbit qui dénonce sa victime qui n'a pas dénoncé sa fuite de données
- + d'attaques par prestataires
- + de rançonlogiciel
- + en + de rapidité d'exploitation de vulnérabilité : la fenêtre entre la divulgation de la CVE et l'exploitation est + rapide
- manque de configuration de base
- Changement dans les politiques de NIS2 : à regarder*
- *Cyber resiliance act* : produit sur le niveau européen secure by design et par défaut