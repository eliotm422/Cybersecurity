
Majorité d'API dans l'industriel.

Architecture : serveur > réseau > poste utilisateur > automates IHM / partie opératives

Regarder si notre automate n'est pas connecté à internet via shodan, on peut remonter depuis longtemps.

Manque de protection des automates : Souvent relié à un routeur pour le contrôle par VPN, peu de mécanismes de sécurités.

Audit : ajouter SI industriel dans le périmètre, équipements et ports

Sensibiliser les risques cyber pour les automates et la partie gestion (peu de budget)

Cibler les PMI, dont certaines entreprises déjà exposées.

L'automate peut-être utilisé pivot d'attaque.

