
Maitre conférencier : WASP

Sommaire :
* Intro IA générative
* Problème
* GOOGLE SAIF
* ANSSI generative AI reference 
* OWASP && Gen AI


# Comprendre l'AI

C'est des maths + proba.

AI à trois gros éléments :
* Les datas : + il y en a plus le système d'AI est content
* Les modèles : ils vont s'occuper de faire des calculs
* Itération : Reboucler

Comment marche le *.gpt :
* Langue naturel NLP : il se base sur des probabilités sur des réponses
* Utilisation de modèle préentrainé
* Information et génération de réponse
* Contexte et cohérence

# Problèmes

Nouvelle surface d'attaque :
* Interne ou externe

Comment répondre à ces problèmes :
* Gouvernance 
* Prendre tous les côtés pratiques de sécurités
* Principe 0 trust
* Principe de limiter les attaques
* Principe de vérification de la validité des données


# Threat Model

En 3 phases, développement utilisation, et mise à jour.

Principe du CIA pour les problèmes.

Il faut bien implémenter DES LE début


# Google SAIF

Framework, de déploiement de sécurité.

# Recommandation de l'ANSSI

Très haut niveau, peu de technique

# OWASP && GEN AI

Devient de + en + gros, ce n'est plus que du web.

Guide du pentest top 10 de la GEN AI de l'OWASP, pleins de versions
Guide de la guidance de la sécurité, la checklist : **LLM AI Cybersecurity & Governance Checklist**


Pentest LLM c'est qql chose à part.

Pour apprendre le : R