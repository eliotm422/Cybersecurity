
+ + d'argents + d'investissement dans le jeu (qui est un ENORME secteur)
+ + de triche pour + d'argents