
![](https://ld-images-2.s3.us-east-2.amazonaws.com/Network+Fundamentals/images/types1.png)


![[kyjxcx7j.bmp]]![](https://ld-images-2.s3.us-east-2.amazonaws.com/Network+Fundamentals/images/types3.png)

![[1eeo4kso.bmp]]

![[6c0waicl.bmp]]
![[7vcrm9hv.bmp]]