RI cosmos : osint sur les avions 
bellingcats : OSINT enquêtes et terrains numériques,openfacto 


newspapermap.com : permet de consulter les journaux dans le monde 
radio.garden : permet d'écouter les radios
behind the name : 
onlyfake :
websdr.org : 
targum/deepl : traduction
dji.com : drone
mattwio : permet de géolocaliser une vidéo 
insecam.org : se connecter à des caméras
webcam world : accès à des caméros
mapchecking : nombre de personnes dans le monde 
isearchfrom : permet de chercher depuis un moteur de recherche 
similar web : permet de connaître les moteurs de recherches les plus connus 
lumen database : voir les demandes de supprimer document 
Wipo.int : permet de chercher marques et brevet 
mapchannels : vu maps gps et streetview 
kartaview, mapillary, hivemapper : permet de voir des photos là où ça serait flouté
glassoor.com : climat social 
skymem.info : adresse mail 
linkedindumper : dump les noms des gens dans l'entreprise
Kapsr / snov / signal hire : donne info numéro 
Epieos : retrouver les numéros
crystalknows.com : connaitre le profile de la personne de linkedin 
unitracker api : permet de connaitre les liens des institutions chinoises 
sinwindie : memo linkedin
whatsmyname.app : permet de chercher voir où existe le profil 
archives.org : compte supprimé/message
spoonbill.io : modificaiton twitter 
Strava pour voir les parcourts
Hunter.io : adresse mail
DEHASHED : trouver le mdp 
Getcontact/truecaller/callapp : numéro de téléphone
data.dicatatoralert. org : trajet des avions
plane-notify : voir les vols des avions
Globe.adsbexchange / flightradar : pour voir les trajets des avions 
marinetraffic : voir les trajets des bateaux
Overpass turbo : permet de voir le lieu en fonction des photos 
OSM finder :idem mais interface graphique 
Suncalc : exposition du soleil et des ombres 
invid-project : permet de débunker les vidéos 
bellingcats : OSINT enquêtes et terrains numériques 