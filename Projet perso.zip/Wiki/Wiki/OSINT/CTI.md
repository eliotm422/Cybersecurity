.Sup

- Sekoia 
- Mandiant 
- CIS A
- Twitter (CERT-FR)

- Renseignement : prise d'info + analyse + prise de décision
- Worm GPT
- PENTEST GPT 

- Donnée : info brut 	
- Renseignement : donnée avec contexte 
- Menace :
	- Capacités techniques 
	- Des opportunités
	- Des objectifs 

- L'intelligence Economique

- Scrapping : méthode de collecte de données, afin de détecter les alertes Cyber

- IOC Un indicateur de compromission, en sécurité informatique, est une déviance ou artefact observé sur un réseau ou dans un système d'exploitation qui indique, avec un haut niveau de certitude, une intrusion informatique.

- On peut farmer des comtps pour pouvoir faire des fausses google AD

- Carding : Vente de carte 


