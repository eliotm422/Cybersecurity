.Microcorruption

# Solution

Bytes de comparaisons stockés en "dur" dans la mémoire .