
IA : RAG quelle apprenne elle même
Déployer la RAG : mettre un environnement de RAG de son côté, et surtout le tester