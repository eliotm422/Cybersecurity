
# Création clef

* On se déplace dans le dossier m

````bash
cd ~/.ssh
````

* On génère une clef : 


