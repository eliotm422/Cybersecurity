
# Installer les prérequis

![[Pasted image 20240112100109.png]]

![[Pasted image 20240112100135.png]]


# Initier la connexion


## Se connecter à un dossier à distance :
![[Pasted image 20240112100234.png]]

Puis dans la barre de recherche du dessus : "Open repesitory from github"

On se connecte, et on réappuye sur open remote repository. 

* On vérifie l'installation 
![[Pasted image 20240112101027.png]]



![[Pasted image 20240112102131.png]]

# Les bonnes pratiques 

## AVANT CHAQUE MODIFICATION

![[Pasted image 20240112102223.png]]

Appuyer sur la roue, pour mettre à jour les modifications
Rafraichir la page 
![[Pasted image 20240112102417.png]]

## Mettre à jour les modifications

Faire les étapes d'avant, et commit & push 
![[Pasted image 20240112102500.png]]

