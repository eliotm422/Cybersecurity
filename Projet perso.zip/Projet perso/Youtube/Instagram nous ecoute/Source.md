# Sources

Meduim : https://brucemadden.medium.com/smartphone-surveillance-is-your-phone-listening-to-you-eeda2c3b39ca
Plusieurs théories, part du principe que le portable nous écoute, mais finalement opte pour "ce sont des coincidences"

Reddit : https://www.reddit.com/r/Futurology/comments/1fbzwpx/is_your_phone_really_listening_to_you_heres_what/
A prendre avec des pincettes, mais les expériences motnrent que cela arrivent des personnes dans le monde.
Intéressant : un qui pense que GOOGLE fait le lien

Lindkln : Pas intéressant 

Nordvpn : https://nordvpn.com/fr/blog/is-my-phone-listening-to-me/
Connaissais déjà le fameux "attends de trigger le mot clef", personne n'a prouvée qu'il écoutait tout

Kaspersky : https://www.kaspersky.com/blog/smartphones-eavesdropping/27817/
Ce qui m'avait lancé dedans (un autre blog), mais certaines personnes parlent pour voir si le portable enregistre les mots.


