Notre portable écoute t'il nos conversation orales ?

Posons le contexte, ça nous ai tous arrivé de discuter à l'oral avec nos amis, de parler de quelque chose de très spécifique est d'avoir une vidéo recommandé derrière.

Il y a pas longtemps avec des amis on a parlé de girafe qui faisait de la moto et j'ai eu pour ma part un réel (Instagram) dessus (oui oui).

Mais alors d'où vient cela ?

Instagram a été interrogé à plusieurs reprises dessus, et ont répondus "Notre algorithme est trop bien fait, c'est pour ça".

Encore plus étonnant, et le nombre d'études sorties sur ce sujet, à savoir, très très peu... Les rares expériences ont été du principe que "oh je vais parler dans le micro, au des pubs s'affichent..."

Je vais essayer de voir directement si on peut capturer ces informations :)

# s